import { Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { Music } from './pages/Music';
import { Cycling } from './pages/Cycling';
import { About } from './pages/About';

export function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/music" element={<Music />} />
      <Route path="/cycling" element={<Cycling />} />
      <Route path="/about" element={<About />} />
    </Routes>
  );
}