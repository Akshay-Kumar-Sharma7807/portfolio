import { motion } from 'framer-motion';

interface Ride {
  title: string;
  distance: string;
  elevation: string;
  date: string;
  image: string;
}

const rides: Ride[] = [
  {
    title: "Mountain Trail Adventure",
    distance: "42km",
    elevation: "850m",
    date: "2024-02-15",
    image: "https://images.unsplash.com/photo-1541625602330-2277a4c46182?q=80&w=2070&auto=format&fit=crop"
  },
  {
    title: "Coastal Route",
    distance: "65km",
    elevation: "320m",
    date: "2024-02-10",
    image: "https://images.unsplash.com/photo-1541625810516-44f1ce894bcd?q=80&w=2070&auto=format&fit=crop"
  }
];

export function Cycling() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 px-8 max-w-4xl mx-auto"
    >
      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-5xl font-bold mb-12"
      >
        Cycling Adventures
      </motion.h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {rides.map((ride, index) => (
          <motion.div
            key={ride.title}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-800 rounded-lg overflow-hidden"
          >
            <img
              src={ride.image}
              alt={ride.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{ride.title}</h3>
              <div className="grid grid-cols-3 gap-4 text-gray-400">
                <div>
                  <p className="text-sm">Distance</p>
                  <p className="font-semibold text-white">{ride.distance}</p>
                </div>
                <div>
                  <p className="text-sm">Elevation</p>
                  <p className="font-semibold text-white">{ride.elevation}</p>
                </div>
                <div>
                  <p className="text-sm">Date</p>
                  <p className="font-semibold text-white">{ride.date}</p>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}